﻿

namespace DemoOO.Models.Edition
{
    internal class Editeur
    {
    }
}
