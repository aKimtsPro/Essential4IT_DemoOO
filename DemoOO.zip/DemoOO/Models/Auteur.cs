﻿
namespace DemoOO.Models
{
    internal class Auteur
    {
        public string Nom;
    }
}
